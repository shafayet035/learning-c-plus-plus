#include <iostream>
using namespace std;

int main() {
    int a, b;

    cin >> a, b;


    if(a > b){
        cout << "a is maximum";
    } else {
        cout << "b is maximum";
    }


    return 0;
}
