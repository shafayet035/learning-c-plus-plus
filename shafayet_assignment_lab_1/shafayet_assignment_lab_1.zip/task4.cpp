#include<iostream>
using namespace std;

int main() {
    int number1, number2, number3;

    cout << "Please Enter Number 1, 2, 3: ";
    cin >> number1 >> number2 >> number3;


    cout << "Summation of Numbers is: " << number1 + number2 + number3 << endl;
    return 0;
}
