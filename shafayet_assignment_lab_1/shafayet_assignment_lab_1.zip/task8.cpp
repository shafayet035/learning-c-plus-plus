#include<iostream>
#include<string>
using namespace std;

int main() {

    int a = 1000, b = 5000;
    double c = 13526.325, d = 132625.36;

    cout << "The Multiplication of a and b is: " << a*b << endl;
    cout << "The Multiplication of c and d is: " << to_string(c*d) << endl;

    return 0;
}
