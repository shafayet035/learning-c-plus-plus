#include<iostream>
using namespace std;

int main() {
    float num = 105.50;
    cout << "The Floating Number is: " << num;
    return 0;
}
