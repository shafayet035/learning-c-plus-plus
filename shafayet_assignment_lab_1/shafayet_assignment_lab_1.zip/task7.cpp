#include<iostream>
using namespace std;

int main() {

    char character;

    cout << "Please Enter Any Character: ";
    cin >> character;

    cout << "You have entered: "<< character <<endl ;
    return 0;
}
