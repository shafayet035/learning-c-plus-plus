#include<iostream>
using namespace std;

int main() {
    int num;
    cout << "Enter a Number ";
    cin >> num;
    cout << "Entered number is" << num << endl;
    return 0;
}
