#include<iostream>
using namespace std;

int main() {
    int num;
    num = 10;
    cout << "The Number is: " << num;
    return 0;
}
