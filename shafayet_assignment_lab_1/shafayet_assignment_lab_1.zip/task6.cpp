#include<iostream>
using namespace std;

int main() {

    int a = 25, b = 5;

    cout << "The Summation is: " << a+b << endl;
    cout << "The Subtraction is: " << a-b << endl;
    cout << "The Multiplication is: " << a*b << endl;
    cout << "The Division is: " << a/b << endl;
    return 0;
}
