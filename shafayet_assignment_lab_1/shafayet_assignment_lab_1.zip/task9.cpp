#include<iostream>
using namespace std;

int main() {

    float r = 5, pi=3.14;

    float area = pi*r*r;


    cout << "The area of the circle is: " << area;

    return 0;
}
